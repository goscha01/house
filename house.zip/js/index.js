
const navToggle = document.querySelector('.nav-toggle');
const navLinks = document.querySelectorAll('.nav__link');
const homePicture = document.querySelector('.albums')
const homeDesign = document.querySelector('.design')
let picturesNames =[]
let detName = ['img/det1.png', 'img/det2.png', 'img/det3.png']
let plans =['img/plan1st.jpg', 'img/plan2st.jpg', 'img/zones.jpg']
let slidePosition = 0;

window.location.replace("#"); //removes internal link from the window path

addPictures(28, homePicture, 'home')
// addPictures(28, homeDesign, 'home')

function addPictures(number, element, folder) {
   
    for (let i = 0; i < number; i++) {
        picturesNames.push(`img/${folder}/${i}.jpg`)
        const a = document.createElement('a')
        a.setAttribute('class', 'album carousel-item')
        a.setAttribute('href', '#')
        a.innerHTML =   `<img src=${picturesNames[i]} alt='' class='album__img'>`
        a.firstElementChild.addEventListener('click', (e) => {
        e.preventDefault()
        addModal (e, a, picturesNames, i, 'img')
       })
      element.appendChild(a)
    }
}



function moveToNextSlide(array) {
    const element = document.getElementsByClassName('album__img--large')
    if (slidePosition === array.length-1) {
        slidePosition = 0
    } else {
        slidePosition +=1
    }
    element[0].setAttribute('src', array[slidePosition])
}

function moveToPrevSlide(array) {
    const element = document.getElementsByClassName('album__img--large')
    if (slidePosition === 0) {
        slidePosition = array.length-1
    } else {
        slidePosition -=1
    }
    element[0].setAttribute('src', array[slidePosition])
}


navToggle.addEventListener('click', () => {
    document.body.classList.toggle('nav-open')
})

navLinks.forEach(link => {
    link.addEventListener('click', () => {
        document.body.classList.remove('nav-open');
    })
})

function contentType (type, array, i) {
    if (type === 'img' || type === 'plan') {
        return `<img src=${array[i]} alt='' class='album__img--large'>`
    } else {
        return  `<embed src="details.txt" class='embed'>`
    }
}

function addModal (e, element, array, i, type) {
    element.removeEventListener('click', addModal)
    e.preventDefault();
    let html = contentType(type, array, i)
    slidePosition = i
    let div = document.createElement('div')
    element.appendChild(div).innerHTML = 
    `<div class='overlay '>
        <div class='container'>
        <button id="close-button"  aria-label="Close">x</button>
\            ${html}
            <div class='carousel-actions'>
            <button id="carousel-button-prev" aria-label="Previous Slide"><</button>
            <button id="carousel-button-next" aria-label="Next Slide">></button>
            </div>
        </div>
     </div>
  `
  document.getElementById('carousel-button-next').addEventListener('click', () => moveToNextSlide(array));
  document.getElementById('carousel-button-prev').addEventListener('click', () => moveToPrevSlide(array));
  document.getElementById('close-button').addEventListener('click', closeModal);
}


function closeModal (e) {
    e.preventDefault();
    const container = document.getElementsByClassName('container')
    container[0].parentElement.remove()
    slidePosition = 0;
}



function   readMore(e) {
    e.preventDefault();
    console.log(e.target.id)
    if(e.target.id === 'img') {
        array = detName
    } else {
        array = plans
    }
   
    addModal(e, e.target.parentElement, array, 0, e.target.id)
    if(e.target.id === 'text')
        document.querySelector('.carousel-actions').remove()
}

