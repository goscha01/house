

async function getCategories(count, offset = 0) {
    let response = await fetch(`https://jservice.io/api/categories?count=${count}&offset=${offset}`);
    const categories = await response.json();

    console.log(categories)

    return categories;
}

const getClueHtml = (clueValue) => {
    return `<div class="my-category-clue" style="grid-row-start: ${clueValue/100+1}">$${clueValue}</div>`
}

const getCategoryHTML =  (category) => {
    return `<div class='title'>${category.title}</div>
            ${getClueHtml(100)}
            ${getClueHtml(200)}
            ${getClueHtml(300)}
            ${getClueHtml(400)}
        `
}

getCategories(5).then(categories => {
    document.body.innerHTML = `
        <div class='board'>
            ${categories.map(getCategoryHTML).join('')}
        </div>
    `
   
})