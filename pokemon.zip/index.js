async function getAllPokemon() {
    let response = await fetch("pokemon.json")
    let data = await response.json();
    
    console.log(data)
    return data;
}

const pokemonCard = (data) => {
    return `
    <div class=card>
        <div class='id'>${data.id}</div>
        <div class='name'>${data.name.english}</div>
        <div class='name'>${data.name.japanese}</div>
        <div class='name'>${data.name.chinese}</div>
        <div class='name'>${data.name.french}</div>
        <div class='type'>${data.type.join(' / ')}</div>
        <div class='stat'>HP: ${data.base.HP}</div>
        <div class='stat'>Attack: ${data.base.Attack}</div>
        <div class='stat'>Defence: ${data.base.Defence}</div>
        <div class='stat'>Speed: ${data.base.Speed}</div>
    </div>
`
} 

function displayPokedex(allPokemon) {
    return document.body.innerHTML = `
    <div class=board>${allPokemon.map(pokemonCard).join(' ')}</div>
`
}

getAllPokemon().then(pokemons => {displayPokedex(pokemons)
    
})