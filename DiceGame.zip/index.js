let gamePlay = true;
let player1Turn = true;
let score1 = 0;
let score2 = 0;

const player1Scoreboard = document.getElementById('player1Scoreboard')
const player2Scoreboard = document.getElementById('player2Scoreboard')
const player1Dice = document.getElementById('player1Dice')
const player2Dice = document.getElementById('player2Dice')
const message = document.getElementById('message')
const rollBtn = document.getElementById("rollBtn")
const resetBtn = document.getElementById("resetBtn")




rollBtn.addEventListener('click', () => {
    player1Dice.innerText = 0;
    player2Dice.innerText = 0;
    let score = Math.floor(Math.random()*6) +1
    if (player1Turn) {
        score1 += score;
        player1Dice.innerText = score;
        player2Dice.setAttribute('class', 'dice');
        player1Dice.setAttribute('class', 'dice active');
        player1Scoreboard.innerText =  score1;
        message.innerText = `Player 2 turn`
    }
    else {
        score2 += score;
        player2Dice.innerText = score;
        player1Dice.setAttribute('class', 'dice');
        player2Dice.setAttribute('class', 'dice active');

        player2Scoreboard.innerText =  score2;
        message.innerText = `Player 1 turn`
    }

    if (score1 > 20) {
        message.innerText = `Player 1 won!`
        switchButtons();
    }
    else if (score2 > 20) {
        message.innerText = `Player 2 won!`
        switchButtons();
    } else {
        player1Turn = !player1Turn;
    }
    
    console.log(score)
})

const switchButtons = () => {
    resetBtn.style.display = 'block'
    rollBtn.style.display ='none'
}


const resetGame =() => {
    message.innerText = `Player 1 Turn`
    player1Dice.innerText = '-';
    player2Dice.innerText = '-';
    player1Scoreboard.innerText =  0;
    player2Scoreboard.innerText =  0;
    resetBtn.style.display = 'none'
    rollBtn.style.display ='block'
    score1 = 0;
    score2 = 0;
    player1Turn = true;
    player2Dice.setAttribute('class', 'dice');
    player1Dice.setAttribute('class', 'dice active');
}
resetBtn.addEventListener('click', (resetGame())

// 1. Hook a click event listener up with the Reset Button
// 2. Create a reset() function that resets the game
// 3. Invoke the reset() function when the Reset Button is clicked