const grid = document.querySelector('.grid')
const startButton = document.getElementById('start')
const score = document.querySelector('#score')
let squares = []
let currentSnake = [0,1,2];
let direction = 1;
let interval = 500;
let scoreNumber = 0;
let timerId = 0; 
let appleIndex = 0;


const startGame = () => {
    
    createGrid()
    currentSnake.forEach(index => squares[index].classList.remove('snake', 'apple'));
    squares[appleIndex].classList.remove('apple');
    clearInterval(timerId)
    timerId = setInterval(move,interval);
    generateApples();
    currentSnake = [0,1,2];
    currentSnake.forEach(index => squares[index].classList.add('snake'))
    direction = 1;
    interval = 500;
    scoreNumber = 0;
    score.textContent = scoreNumber;
}

startButton.addEventListener('click', () => startGame())

function createGrid() {
    for (let i = 0; i<100; i++) {
        const square = document.createElement('div');
        square.classList.add('square')
        grid.appendChild(square)
        squares.push(square);
    }
}




function move() {

    //border control
    let head = currentSnake[currentSnake.length-1]
    if (
        (head%10 === 0 && direction === -1) ||
        (head%10 === 9 && direction === 1) ||
        (head -10 < 0 && direction === -10) ||
        (head + 10 > 100 && direction === 10) ||
        (squares[head + direction].classList.contains('snake'))
    )
        return clearInterval(timerId)

    //snake moving
    let tail = currentSnake.shift()
    squares[tail].classList.remove('snake')
    currentSnake.push(head + direction)
    currentSnake.forEach(index => squares[index].classList.add('snake'))

    //apple eating
    if (squares[head].classList.contains('apple')) {
        squares[head].classList.remove('apple');

        squares[tail].classList.add('snake')
        currentSnake.unshift(tail);
        generateApples();
        scoreNumber += 1
        score.textContent = scoreNumber;
        clearInterval(timerId)
        interval -= 25; 
        timerId = setInterval(move,interval)
    }


currentSnake.forEach(index => squares[index].classList.add('snake'))
    
}



function generateApples() {
    
    do {
        appleIndex = Math.floor(Math.random()*101)
    } while (squares[appleIndex].classList.contains('snake'))
    squares[appleIndex].classList.add('apple')
}

// startButton.addEventListener('click', () =>  move())

// move()

function control(e) {
 
    switch (e.keyCode) {
        case 39:
            console.log(39)
            direction = 1;
            break;
        case 38:
            console.log(38)
            direction = -10;
            break;
        case 37:
            console.log(37)
            direction = -1;
            break;
        case 40:
            console.log(40)
            direction = 10;
             break;

    }
}
document.addEventListener('keydown', control)