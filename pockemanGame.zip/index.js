const grid = document.querySelector('.grid')
const score = document.getElementById('score')
const width = 28;
const squares = [];
let scoreNumber = 0

score.innerText = scoreNumber

//28 * 28 = 784
  // 0 - pac-dots
  // 1 - wall
  // 2 - ghost-lair
  // 3 - power-pellet
  // 4 - empty

const layout = [
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1,
    1,3,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,3,1,
    1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1,
    1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,1,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,1,1,
    1,1,1,1,1,1,0,1,1,4,4,4,4,4,4,4,4,4,4,1,1,0,1,1,1,1,1,1,
    1,1,1,1,1,1,0,1,1,4,1,1,1,2,2,1,1,1,4,1,1,0,1,1,1,1,1,1,
    1,1,1,1,1,1,0,1,1,4,1,2,2,2,2,2,2,1,4,1,1,0,1,1,1,1,1,1,
    4,4,4,4,4,4,0,0,0,4,1,2,2,2,2,2,2,1,4,0,0,0,4,4,4,4,4,4,
    1,1,1,1,1,1,0,1,1,4,1,2,2,2,2,2,2,1,4,1,1,0,1,1,1,1,1,1,
    1,1,1,1,1,1,0,1,1,4,1,1,1,1,1,1,1,1,4,1,1,0,1,1,1,1,1,1,
    1,1,1,1,1,1,0,1,1,4,1,1,1,1,1,1,1,1,4,1,1,0,1,1,1,1,1,1,
    1,0,0,0,0,0,0,0,0,4,4,4,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,1,
    1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1,
    1,0,1,1,1,1,0,1,1,1,1,1,0,1,1,0,1,1,1,1,1,0,1,1,1,1,0,1,
    1,3,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,3,1,
    1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,
    1,1,1,0,1,1,0,1,1,0,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,1,1,1,
    1,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,1,
    1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1,
    1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 
]

//create board

function createBoard () {
    for (let i = 0; i < layout.length; i++) {
        const square = document.createElement('div')
        grid.appendChild(square)
        squares.push(square)

        if (layout[i] === 0) {
            squares[i].classList.add('pac-dot')
        } else if (layout[i] === 1) {
            squares[i].classList.add('wall')
        } else if (layout[i] === 2) {
            squares[i].classList.add('ghost-lair')
        } else  if (layout[i] === 3) {
            squares[i].classList.add('power-pellet')
        } else if   (layout[i] === 4) {
            squares[i].classList.add('empty')
        }
    }
}

createBoard()

class Ghost {
    constructor(className, startIndex, speed) {
        this.className = className
        this.startIndex = startIndex
        this.speed = speed
        this.currentIndex = startIndex
        this.isScared = false
        this.timerId = NaN
    }
}

const ghosts = [
    new Ghost('blinky', 348, 250),
    new Ghost('pinky', 376, 400),
    new Ghost('inky', 351, 300),
    new Ghost('clyde', 379, 500)
]

//stsarting position of pacman
let pacmanCurrentIndex = 389;
squares[pacmanCurrentIndex].classList.add('pacman')

document.addEventListener('keydown', control)

function control(e) {

    let initialPosition =  pacmanCurrentIndex
    switch (e.keyCode) {
        case 40:

            pacmanCurrentIndex = pacmanCurrentIndex + width;
            break;
        case 38:

            pacmanCurrentIndex = pacmanCurrentIndex - width;
            break;
        case 37:

            pacmanCurrentIndex = pacmanCurrentIndex - 1;
            break;
        case 39:

            pacmanCurrentIndex = pacmanCurrentIndex + 1;
            break;
    }

    if (pacmanCurrentIndex === 363) {
        pacmanCurrentIndex = 391
    }

    if (pacmanCurrentIndex === 392) {
        pacmanCurrentIndex = 364
    }

    if (!squares[pacmanCurrentIndex].classList.contains('wall') && 
       !squares[pacmanCurrentIndex].classList.contains('ghost-lair')) {
        squares[initialPosition].classList.remove('pacman')
        squares[pacmanCurrentIndex].classList.add('pacman')
    } else {
        // if (!squares[pacmanCurrentIndex  - 1].classList.contains('wall')) {
        //     squares[initialPosition].classList.remove('pacman')
        //     squares[pacmanCurrentIndex - width].classList.add('pacman')
        //     pacmanCurrentIndex = pacmanCurrentIndex - width
        // } else if (!squares[pacmanCurrentIndex  + 1].classList.contains('wall')) {
        //     squares[initialPosition].classList.remove('pacman')
        //     squares[pacmanCurrentIndex + width].classList.add('pacman')
        //     pacmanCurrentIndex = pacmanCurrentIndex + width
        // } else {
        //     squares[initialPosition].classList.add('pacman')
        //     pacmanCurrentIndex = initialPosition
        // }
            squares[initialPosition].classList.add('pacman')
            pacmanCurrentIndex = initialPosition
      
    }


    scores()
    gameOver () 
    checkForWin()
}

function scores () {
    
    if (squares[pacmanCurrentIndex].classList.contains('pac-dot')) {
        squares[pacmanCurrentIndex].classList.remove('pac-dot')
        scoreNumber += 1
        // squares[pacmanCurrentIndex].classList.add('pacman')
    }

    if (squares[pacmanCurrentIndex].classList.contains('power-pellet')) {
        squares[pacmanCurrentIndex].classList.remove('power-pellet')
        scoreNumber += 10
        ghosts.forEach(ghost => {
            ghost.isScared = true
            ghost.speed *= 2
        })
        setTimeout(() => ghosts.forEach(ghost => ghost.isScared = false), 10000)
    }

    // if (squares[pacmanCurrentIndex].classList.contains('scared-ghost')) {
    //         squares[pacmanCurrentIndex].classList.remove('scared-ghost', 'ghost', ghost.className)
    //         scoreNumber += 100
    //         squares[ghost.startIndex].classList.add(ghost.className)
    //         squares[ghost.startIndex].classList.add('ghost')

    // }


    score.innerText = scoreNumber
}




//starting position of ghost
ghosts.forEach(ghost => {
    squares[ghost.currentIndex].classList.add(ghost.className)
    squares[ghost.currentIndex].classList.add('ghost')
})

ghosts.forEach(ghost => ghostMove(ghost))


function ghostMove(ghost) {
    const directions = [-1, +1, -width, +width]
    let direction = directions[Math.floor(Math.random()*directions.length)]
    console.log(direction)

    ghost.timerId = setInterval(() => {
        if (!squares[ghost.currentIndex + direction].classList.contains('wall') && 
            !squares[ghost.currentIndex + direction].classList.contains('ghost')
            ) {
            squares[ghost.currentIndex].classList.remove(ghost.className)
            squares[ghost.currentIndex].classList.remove('ghost', 'scared-ghost')
            ghost.currentIndex += direction
            squares[ghost.currentIndex].classList.add(ghost.className)
            squares[ghost.currentIndex].classList.add('ghost')
        } else {
            // if (!squares[ghost.currentIndex + direction  - width].classList.contains('wall')) {
            //     squares[ghost.currentIndex].classList.remove(ghost.className)
            //     squares[ghost.currentIndex + direction - width].classList.add(ghost.className)
            //     ghost.currentIndex = ghost.currentIndex + direction - width
            // } else if (!squares[ghost.currentIndex + direction  + width].classList.contains('wall')) {
            //     squares[ghost.currentIndex].classList.remove(ghost.className)
            //     squares[ghost.currentIndex + direction + width].classList.add(ghost.className)
            //     ghost.currentIndex = ghost.currentIndex + direction + width
            // } else {
            //     direction = getGhostDirection()
            // }
            direction = directions[Math.floor(Math.random()*directions.length)]
        
        }
        if (ghost.isScared) {
            console.log('SCARED!')
            squares[ghost.currentIndex].classList.add('scared-ghost')

        }
        if (ghost.isScared && squares[ghost.currentIndex].classList.contains('pacman')) {
            squares[ghost.currentIndex].classList.remove('scared-ghost', 'ghost', ghost.className)
            ghost.currentIndex = ghost.startIndex
            squares[ghost.startIndex].classList.add(ghost.className)
            squares[ghost.startIndex].classList.add('ghost')
            scoreNumber += 100
            score.innerText = scoreNumber
        }

        gameOver () 
    }, ghost.speed)
 
}

// function firstMove(ghost) {
//     const directions = [-1, +1, -width]
//     do {if (!squares[ghost.currentIndex + direction].classList.contains('wall') && 
//     !squares[ghost.currentIndex + direction].classList.contains('ghost')
//     ) {
//         ghost.currentIndex += direction[0]
//         squares[ghost.currentIndex].classList.add(ghost.className)
//         squares[ghost.currentIndex].classList.add('ghost')
//         squares[ghost.currentIndex].classList.remove(ghost.className)
//         squares[ghost.currentIndex].classList.remove('ghost', 'scared-ghost')
//     }
       

//     } while ( !squares[pacmanCurrentIndex].classList.contains('ghost-lair'))
// }


function gameOver () {
    if (squares[pacmanCurrentIndex].classList.contains('ghost') &&
        !squares[pacmanCurrentIndex].classList.contains('scared-ghost')) {
            score.innerText = 'Game over'
        ghosts.forEach(ghost =>  clearInterval(ghost.timerId))
        document.removeEventListener('keydown', control)
        }
}

function checkForWin() {
    if (score === 274) {
        score.innerText = 'You won'
        ghosts.forEach(ghost =>  clearInterval(ghost.timerId))
        document.removeEventListener('keydown', control)
    }
}